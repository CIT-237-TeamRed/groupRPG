#pragma once
#ifndef TOOL_H
#define TOOL_H
#include "Item.h"
class Tool : public Item{
private:

public:
    //virtual void use() = 0;
};
#endif