#include "Item.h"

void Item::setName(string name) {
	this->name = name;
}